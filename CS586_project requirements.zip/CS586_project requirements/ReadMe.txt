
The materials in this file are all from the professor.