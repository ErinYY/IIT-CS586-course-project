


Please DO NOT just copy, you won't get a high score if you just copy something online. 


========================================================


source code environment:

java version "1.8.0_152"
Java(TM) SE Runtime Environment (build 1.8.0_152-b16)
Java HotSpot(TM) 64-Bit Server VM (build 25.152-b16, mixed mode)

The source code is in the src folder.

If some pictures are not readable in the report, please check the .jpg files in this folder.

