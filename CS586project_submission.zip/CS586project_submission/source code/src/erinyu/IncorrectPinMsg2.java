package erinyu;

public class IncorrectPinMsg2 extends IncorrectPinMsgAbstract {

	@Override
	public void showMessage() {
		System.out.println("Entered pin is incorrect");

	}

}
