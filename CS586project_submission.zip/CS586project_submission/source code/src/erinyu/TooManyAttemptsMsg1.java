package erinyu;

public class TooManyAttemptsMsg1 extends TooManyAttemptsMsgAbstract {

	@Override
	public void showMessage() {
		System.out.println("Too many attempts.\nLogging out....");

	}

}
