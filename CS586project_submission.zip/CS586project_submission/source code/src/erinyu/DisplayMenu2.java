package erinyu;

public class DisplayMenu2 extends DisplayMenuAbstract {

	@Override
	public void displayMenu() {
		
		System.out.println("Operations Menu:");
		System.out.println("\t3.DEPOSIT\n\t4.WITHDRAW\n\t5.BALANCE\n\t6.LOGOUT\n\t7.suspend\n\t8.activate\n\t9.close\n\t10.quit\n\n");

		

	}

}
