package erinyu;

public class Close2 extends CloseAbstract {

	@Override
	public boolean process() {
		System.exit(0);
		return true;
	}

}
