package erinyu;

public class Datastore1<T> extends DatastoreAbstract<T> {
	
	private int p; //temp pin
	private int y; //temp userID
	private int a; //temp balance
	
	private int pin; //pin
	private int uID; //userID
	private int balance; //balance
	
	private int temp_deposit; //temp deposit
	private int temp_withdraw; //temp withdraw
	private float penalty; // penalty amount
	
	/*
	 * Constructor 
	 * params: none
	 * initializes Datastore1 object
	 */
	public Datastore1() {
		penalty = 20;
	}
	
	/*
	 * storeData method to store temp values
	 * params: Pin, userID, balance
	 * returns true after being finished.
	 */
	@Override
	public boolean storeData(int p, int y, T a) {
		// TODO Auto-generated method stub
		
		this.p = p;
		this.y = y;
		if(a instanceof Integer) {
			this.a = Integer.parseInt(String.valueOf(a));
		}
		return true;
	}
	
	/*
	 * initData method to initialize using temp variables
	 * params: none
	 * returns true after being finished.
	 */
	@Override
	public boolean initData() {
		this.pin = p;
		this.uID = y;
		this.balance = a;
		
		return true;
	}

	//returns pin
	@Override
	public int getPin() {
		return this.pin;
	}

	//returns balance
	@Override
	public int getBalance() {
		return this.balance;
	}

	@Override
	public float getBalance2() {
		return 0;
	}

	//processes the deposit
	@Override
	public boolean deposit(){
		this.balance += temp_deposit;
		return true;
	}

	//stores the deposit amount
	@Override
	public boolean storeDepositAmt(T deposit) {
		this.temp_deposit = Integer.parseInt(String.valueOf(deposit));
		return true;
	}
	
	//processes withdraw
	@Override
	public boolean withdraw(){
		this.balance -= temp_withdraw;
		return true;
	}

	//stores the withdraw amount
	@Override
	public boolean storeWithdrawAmt(T deposit) {
		this.temp_withdraw = Integer.parseInt(String.valueOf(deposit));
		return true;
	}

	//returns userID
	@Override
	public int getUserId() {
		return this.uID;
	}
 
 	//processes penalty
	@Override
	public boolean withdrawWithPenalty() {
		
		this.balance -= (penalty);
		return true;
	}


}
