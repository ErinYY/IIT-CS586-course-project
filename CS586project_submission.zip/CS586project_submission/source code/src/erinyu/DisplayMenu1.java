package erinyu;

public class DisplayMenu1 extends DisplayMenuAbstract {

	@Override
	public void displayMenu() {
		
		System.out.println("Operations Menu:");
		System.out.println("\t3.Deposit\n\t4.Withdraw\n\t5.balance\n\t6.Logout\n\t7.Lock\n\t8.unlock\n\t9.quit\n\n");
		
	}

}
