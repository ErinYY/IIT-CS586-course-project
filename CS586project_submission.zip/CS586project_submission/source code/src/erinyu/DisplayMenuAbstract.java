package erinyu;

public abstract class DisplayMenuAbstract {
	
	public abstract void displayMenu();

}
