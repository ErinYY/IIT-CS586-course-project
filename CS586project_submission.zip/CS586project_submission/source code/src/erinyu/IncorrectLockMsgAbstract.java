package erinyu;

public abstract class IncorrectLockMsgAbstract {
	
	public abstract boolean showMessage();

}
