package erinyu;

public class Datastore2<T> extends DatastoreAbstract<T> {

	private int p; //temp pin
	private int y; //temp userID
	private float a; //temp balance

	private int pin; //pin
	private int uID; //userID
	private float balance; //balance

	private float temp_deposit; //temp deposit
	private float temp_withdraw; //temp withdraw

	//constructor
	public Datastore2() {

	}

	/*
	 * storeData method to store temp values
	 * params: Pin, userID, balance
	 * returns true after being finished.
	 */
	@Override
	public boolean storeData(int p, int y, T a) {

		this.p = p;
		this.y = y;
		if(a instanceof Float){
			this.a = Float.parseFloat(String.valueOf(a));
		}
		return true;
	}

	//returns pin
	@Override
	public int getPin() {
		return this.pin;
	}

	@Override
	public int getBalance() {
		return 0;
	}

	//returns balance
	@Override
	public float getBalance2() {
		return this.balance;
	}

	//stores deposit amount
	@Override
	public boolean storeDepositAmt(T deposit) {
		this.temp_deposit = Float.parseFloat(String.valueOf(deposit));
		return true;
	}

	//stores withdraw amount
	@Override
	public boolean storeWithdrawAmt(T deposit) {
		this.temp_withdraw = Float.parseFloat(String.valueOf(deposit));
		return true;
	}

	//returns userID
	@Override
	public int getUserId() {
		return this.uID;
	}

	/*
	 * initData method to initialize using temp variables
	 * params: none
	 * returns true after being finished.
	 */
	@Override
	public boolean initData() {

		this.pin = p;
		this.uID = y;
		this.balance = a;

		return true;

	}

	//processes withdraw
	@Override
	public boolean withdraw() {
		this.balance -= temp_withdraw;
		return true;
	}

	//processes deposit
	@Override
	public boolean deposit() {
		this.balance += temp_deposit;
		return true;
	}

	//processes penalty
	@Override
	public boolean withdrawWithPenalty() {
		return false;
	}

}
