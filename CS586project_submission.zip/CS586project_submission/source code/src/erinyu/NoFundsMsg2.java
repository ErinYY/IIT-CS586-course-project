package erinyu;

public class NoFundsMsg2 extends NoFundsMsgAbstract {

	@Override
	public void showMessage() {

		System.out.println("Not enough funds to withraw");

	}

}
