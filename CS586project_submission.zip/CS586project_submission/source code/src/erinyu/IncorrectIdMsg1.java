package erinyu;

public class IncorrectIdMsg1 extends IncorrectIdMsgAbstract {
	
	public void showMessage(){
		System.out.println("ID incorrect");
	}

}
