package erinyu;

public abstract class PromptPinMsgAbstract {
	
	public abstract boolean showMessage(); 

}
