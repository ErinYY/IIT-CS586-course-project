package erinyu;

public abstract class MakeWithdrawBelowMinBalanceAbstract {

	public abstract boolean process(DatastoreAbstract dataStore);

}
