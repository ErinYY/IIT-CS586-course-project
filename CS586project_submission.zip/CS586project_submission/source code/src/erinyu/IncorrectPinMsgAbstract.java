package erinyu;

public abstract class IncorrectPinMsgAbstract {

	public abstract void showMessage();
}
