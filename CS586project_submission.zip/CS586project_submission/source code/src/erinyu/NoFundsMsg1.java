package erinyu;

public class NoFundsMsg1 extends NoFundsMsgAbstract {

	@Override
	public void showMessage() {
		
		System.out.println("Not enough funds to withraw");
		
	}

}
