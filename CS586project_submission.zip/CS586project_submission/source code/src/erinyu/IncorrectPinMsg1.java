package erinyu;

public class IncorrectPinMsg1 extends IncorrectPinMsgAbstract {

	@Override
	public void showMessage() {
		System.out.println("Entered pin is incorrect");
	}

}
