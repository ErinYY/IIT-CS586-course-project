package erinyu;

public abstract class InitAccountAbstract {
	
	public abstract boolean process(DatastoreAbstract dataStore);

}
