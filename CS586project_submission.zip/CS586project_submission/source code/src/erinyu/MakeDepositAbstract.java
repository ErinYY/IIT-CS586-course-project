package erinyu;

public abstract class MakeDepositAbstract {

	public abstract void process(DatastoreAbstract dataStore);

}
