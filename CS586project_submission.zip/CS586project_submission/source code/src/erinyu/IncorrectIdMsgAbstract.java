package erinyu;

public abstract class IncorrectIdMsgAbstract {
	
	public abstract void showMessage();

}
