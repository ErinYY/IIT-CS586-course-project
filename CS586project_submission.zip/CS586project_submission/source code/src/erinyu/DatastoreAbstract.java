package erinyu;

public abstract class DatastoreAbstract<T> {

	public abstract boolean storeData(int p, int y, T a);
	
	public abstract boolean initData();
	
	public abstract int getPin();
	
	public abstract int getBalance();

	public abstract float getBalance2();
	
	public abstract boolean storeDepositAmt(T deposit);
	
	public abstract boolean storeWithdrawAmt(T deposit);
	
	public abstract int getUserId();

	public abstract boolean withdraw();

	public abstract boolean deposit();
	
	public abstract boolean withdrawWithPenalty();
	
	
}
