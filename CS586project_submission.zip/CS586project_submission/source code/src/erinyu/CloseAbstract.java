package erinyu;

public abstract class CloseAbstract {

	public abstract boolean process();
}
