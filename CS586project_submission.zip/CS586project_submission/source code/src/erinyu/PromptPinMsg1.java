package erinyu;

public class PromptPinMsg1 extends PromptPinMsgAbstract {

	@Override
	public boolean showMessage() {
		System.out.println("Choose pin option from below to Enter pin.");
		return true;
	}

}
