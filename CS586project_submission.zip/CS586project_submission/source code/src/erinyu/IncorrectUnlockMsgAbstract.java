package erinyu;

public abstract class IncorrectUnlockMsgAbstract {
	
	public abstract boolean showMessage();

}
