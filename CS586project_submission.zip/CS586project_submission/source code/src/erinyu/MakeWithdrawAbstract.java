package erinyu;

public abstract class MakeWithdrawAbstract {

	public abstract boolean process(DatastoreAbstract dataStore);

}
