package erinyu;

public abstract class TooManyAttemptsMsgAbstract {
	
	public abstract void showMessage();

}
