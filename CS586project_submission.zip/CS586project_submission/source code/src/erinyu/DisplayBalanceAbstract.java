package erinyu;

public abstract class DisplayBalanceAbstract {

	public abstract void displayBalance(DatastoreAbstract dataStore);

}
