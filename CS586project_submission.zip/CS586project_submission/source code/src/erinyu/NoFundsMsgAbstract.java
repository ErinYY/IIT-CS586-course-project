package erinyu;

public abstract class NoFundsMsgAbstract {
	
	public abstract void showMessage();

}
