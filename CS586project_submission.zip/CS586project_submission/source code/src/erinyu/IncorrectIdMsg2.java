package erinyu;

public class IncorrectIdMsg2 extends IncorrectIdMsgAbstract {

	@Override
	public void showMessage() {
		System.out.println("ID incorrect");

	}

}
