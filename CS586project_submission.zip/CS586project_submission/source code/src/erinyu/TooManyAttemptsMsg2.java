package erinyu;

public class TooManyAttemptsMsg2 extends TooManyAttemptsMsgAbstract {

	@Override
	public void showMessage() {
		System.out.println("Too many attempts.\nLogging out....");

	}

}
